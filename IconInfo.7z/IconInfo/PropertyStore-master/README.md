# PropertyStore
.NET Class Library for processing Serialized Property Stores as documented in [MS-PROPSTORE](https://msdn.microsoft.com/en-us/library/dd871346.aspx).

This Class Library is mainly used as support library for the [ShellLink](https://github.com/securifybv/ShellLink) Class Library.

![.NET Core](https://github.com/securifybv/PropertyStore/workflows/.NET%20Core/badge.svg)
